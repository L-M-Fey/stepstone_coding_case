import java.util.Scanner;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.Authenticator;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.PasswordAuthentication;
import java.net.URL;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

public class Api {
    static final String kuser = "testuser";
    static final String kpass = "testpassword";

    static class RHAuthenticator extends Authenticator {
        public PasswordAuthentication getPasswordAuthentication() {
            return (new PasswordAuthentication(kuser, kpass.toCharArray()));
        }
    }

    private static Document convertStringToXMLDocument(String xmlString) 
    {
        //Parser that produces DOM object trees from XML content
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
         
        //API to obtain DOM Document instance
        DocumentBuilder builder = null;
        try
        {
            //Create DocumentBuilder with default configuration
            builder = factory.newDocumentBuilder();
             
            //Parse the content to Document object
            Document doc = builder.parse(new InputSource(new StringReader(xmlString)));
            return doc;
        } 
        catch (Exception e) 
        {
            e.printStackTrace();
        }
        return null;
    }

    public static void main(String[] args) {
        Authenticator.setDefault(new RHAuthenticator());
        //bereite Rest API vor
        String apiURL = "https://reststop.randomhouse.com/resources/authors";

        //bereite Scanner für Benutzereingabe vor
        Scanner input = new Scanner(System.in);

        //frage Benutzer nach Vorname und Nachname als Parameter
        System.out.println("Bitte gebe Vorname ein: ");
        String firstName = input.nextLine();
        System.out.println("Bitte gebe Nachname ein: ");
        String lastName = input.nextLine();

        //falls benutzergegebene Parameter nicht vorhanden sind, benutze Default-Werte
        if (firstName.trim().length() == 0) firstName = "Dan";
        if (lastName.trim().length() == 0) lastName = "Brown";

        //bereite Query für die Rest API vor
        String query = "firstName="+firstName+"&lastName="+lastName;
        try {
            //rufe die Rest API auf
            URL url = new URL(apiURL + "?" + query);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();

            //lese das Ergebnis der Query als String aus und speichere sie in eine Variable
            InputStream is = con.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(is));
            String readerString = "";
            String str;
            while ((str = reader.readLine()) != null) {
                readerString = str;
            }

            //parse die XML aus dem gespeicherten String
            Document doc = convertStringToXMLDocument(readerString);

            //hole die Instanzen der Autoren aus dem XML und iteriere über sie
            NodeList authors = doc.getFirstChild().getChildNodes();
            for (int i = 0; i < authors.getLength(); i++) {
                //caste aktuelle Instanze des "author" XML-Objekt auf die Element-Klasse
                Element author = (Element) authors.item(i);

                //Default-Werte für die Daten, die wir ausgeben wollen
                String authorID = "";
                String authorName = "";
                int titlesCount = 0;

                //hole die nötigen Informationen per getElementsByTagName raus (deshalb auch das vorherige Casten)
                authorID = author.getElementsByTagName("authorid").item(0).getTextContent();
                authorName = author.getElementsByTagName("authorlastfirst").item(0).getTextContent();
                titlesCount = author.getElementsByTagName("titles").item(0).getChildNodes().getLength();

                //gebe Ergebnis aus
                System.out.println(authorID+"; "+authorName+"; "+titlesCount);
            }

            //schließe den Reader, nachdem die XML ausgelesen und alle nötigen Informationen ausgebenen wurden
            reader.close();
            input.close();
        } catch (MalformedURLException mue) {
            // TODO Auto-generated catch block
            mue.printStackTrace();
        } catch (IOException ioe) {
            // TODO Auto-generated catch block
            ioe.printStackTrace();
        }
    }
}